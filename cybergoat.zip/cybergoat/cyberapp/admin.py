from django.contrib import admin
from cyberapp.models import UserProfileInfoForm


# Register your models here.
admin.site.register(UserProfileInfoForm)
