from django.apps import AppConfig


class cyberappConfig(AppConfig):
    name = 'cyberapp'
