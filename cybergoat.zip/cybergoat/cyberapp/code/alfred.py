import requests,json

response = requests.post("https://andruxnet-random-famous-quotes.p.rapidapi.com/?cat=famous&count=10",
  headers={
    "X-RapidAPI-Host": "andruxnet-random-famous-quotes.p.rapidapi.com",
    "X-RapidAPI-Key": "233b8f2729msh68d488b3396703fp192de9jsn5518666bced1"
  }
).json()


print(response)
