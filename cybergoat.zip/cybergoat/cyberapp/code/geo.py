import requests

try:
    response = requests.get('https://api.ipify.org?format=json')
    response = response.json()

    ip = response['ip']

except KeyError:
    ip= '8.8.8.8'



try:
    api_key= '6519f989a5b6fe13492c7ac4482a4204290fa6a842aff9e6494ca56b'
    r= requests.get('https://api.ipdata.co/{}?api-key={}'.format(ip, api_key))
    r = r.json()
    city = r['city']
    location = '{}, {}'.format(r['city'],r['region'])
    postal = r['postal']
    timezone = r['time_zone']['name']
    tor = r['threat']['is_tor']
    proxy = r['threat']['is_proxy']
    anonymous= r['threat']['is_anonymous']
    attacker = r['threat']['is_known_attacker']
    abuser = r['threat']['is_known_abuser']
    threat = r['threat']['is_threat']
    country_code = r['country_code']
    display = 'Your IP: {} || Location: {}'.format(ip, location)
    latitude = r['latitude']
    longitude = r['longitude']
    region_code = r['region_code']

except KeyError:
    ip = None
    city = None
    location = None
    postal = None
    timezone = None
    tor = True
    proxy = True
    anonymous= True
    attacker = True
    abuser = True
    threat = True
    country_code = None
    display = None
    latitude =  None
    longitude = None


#check IP and block access to those considered a threat
block = False
if tor or proxy or anonymous or attacker or abuser or threat == True:
    print('Malicious variables detected with {}'.format(ip))
    bad_list = {'tor':tor, 'proxy':proxy, 'anonymous':anonymous,'attacker':attacker, 'abuser':abuser, 'threat':threat}

    for x,y in bad_list.items():
        if y ==True:
            block = True
