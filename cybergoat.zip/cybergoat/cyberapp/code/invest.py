import requests
import matplotlib.pyplot as plt
import numpy as np


symbol = input()
response = requests.post("https://investors-exchange-iex-trading.p.rapidapi.com/stock/{}/time-series".format(symbol),
  headers={
    "X-RapidAPI-Host": "investors-exchange-iex-trading.p.rapidapi.com",
    "X-RapidAPI-Key": "233b8f2729msh68d488b3396703fp192de9jsn5518666bced1"
  }
)
response = response.json()
date_list=[]
open_price = []
close_price = []


for x in range(0, 21):
    open_price.append(response[x]['open'])
    close_price.append(response[x]['close'])
    date_list.append(response[x]['label'])


plt.plot(date_list,open_price, color='red', marker='o')
plt.title('21 Day History', fontsize=14)
plt.ylabel('Price $', fontsize=14)
plt.xlabel('Date', fontsize=14)
plt.grid(True)
plt.show()
