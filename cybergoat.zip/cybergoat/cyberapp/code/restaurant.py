import requests, random
from cyberapp.code.geo import longitude, latitude


# gathers restaurant information
api_key ='3619e2694ed7d98c6bb58103ed846cf6'


try:
    req = requests.post('https://developers.zomato.com/api/v2.1/search?count=10&lat={}&lon={}&sort=rating'.format(latitude,longitude),
    headers={
    "X-RapidAPI-Host": "ZomatoraygorodskijV1.p.rapidapi.com",
    "X-RapidAPI-Key": "233b8f2729msh68d488b3396703fp192de9jsn5518666bced1",
    "Content-Type": "application/x-www-form-urlencoded"
    },
    params={
    'apikey':'3619e2694ed7d98c6bb58103ed846cf6'
    }
    )

    req = req.json()
    restaurant = {}
    count = []
    for x in req['restaurants']:
        count.append(x)

    rand = random.randint(0,(len(count)-1)) # generate a random number
    name = req['restaurants'][rand]['restaurant']['name']
    location= req['restaurants'][rand]['restaurant']['location']['address']
    cuisines= req['restaurants'][rand]['restaurant']['cuisines']
    timings= req['restaurants'][rand]['restaurant']['timings']
    highlights= ', '.join(req['restaurants'][rand]['restaurant']['highlights'])
    costs = req['restaurants'][rand]['restaurant']['average_cost_for_two']
    user_rating= req['restaurants'][rand]['restaurant']['user_rating']['aggregate_rating']
    all_reviews= req['restaurants'][rand]['restaurant']['all_reviews_count']
    votes = req['restaurants'][rand]['restaurant']['user_rating']['votes']
    currency =req['restaurants'][rand]['restaurant']['currency']
    image = req['restaurants'][rand]['restaurant']['thumb']



    reviews = 'Avg Rating: \t {} Votes: {}'.format(user_rating, votes)
except KeyError:
    print('Error: No data was available.')

    '''
    name = ''
    location= ''
    cuisines= ''
    timings= ''
    highlights= ''
    costs = 0
    user_rating= None
    all_reviews= None
    votes = None
    currency = None
    image=None
    '''
