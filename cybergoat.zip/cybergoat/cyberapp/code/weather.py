import requests,json, random
from cyberapp.code.geo import *




api_key = '363ec8bdb9b196994ea122856274fb72'
try:
    req = requests.get('https://api.openweathermap.org/data/2.5/weather?q={},{}&APPID={}'.format(city,country_code, api_key))
    req = req.json()
    print(req)

    wind = req['wind']['speed']
    today= req['weather'][0]['main'].title()
    humidity= req['main']['humidity']
    description ='{} with {}% Humidity. Wind speeds at {} mph.\
    '.format(req['weather'][0]['description'].title(),
humidity, wind)
    kelvin = req['main']['temp']

    temp = (9/5*(kelvin - 273)) + 32 #converts to fahrenheit

    celcius = (temp-32)*5/9
    celcius='{:.2f}'.format(celcius)
    temp = '{:.2f}'.format(temp)

    r = requests.get("https://webcamstravel.p.rapidapi.com/webcams/list/nearby={},\
    {},100?lang=en&show=webcams%3Aimage%2Clocation".format(latitude,longitude),
    headers={
    "X-RapidAPI-Host": "webcamstravel.p.rapidapi.com",
    "X-RapidAPI-Key": "233b8f2729msh68d488b3396703fp192de9jsn5518666bced1"
    }).json()

    rand = random.randint(0, (len(r['result']['webcams'])-1))
    image = r['result']['webcams'][rand]['image']['current']['thumbnail']


except KeyError:
    wind=None
    today=''
    humidity =None
    description=''
    kelvin=500
    temp=500
    celcius =100
    temp=90
    image = "n/a"
